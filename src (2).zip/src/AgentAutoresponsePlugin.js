import { TextareaItem,Actions } from '@twilio/flex-ui';
import { FlexPlugin } from 'flex-plugin';
import React from 'react';
import CannedResponses from './components/CannedResponses';

const PLUGIN_NAME = 'AgentAutoresponsePlugin';

export default class AgentAutoresponsePlugin extends FlexPlugin {

  constructor() {
    super(PLUGIN_NAME);
    this.state={
      nameofcx:""
    }
  }

  /**
   * This code is run when your plugin is being started
   * Use this to modify any UI components or attach to the actions framework
   *
   * @param flex { typeof import('@twilio/flex-ui') }
   * @param manager { import('@twilio/flex-ui').Manager }
   */
  init(flex, manager) {
    flex.Actions.addListener("afterAcceptTask", (payload) => {
  //  this.state.nameofcx   =payload.task.attributes.name;
  this.setState({nameofcx:payload.task.attributes.name})
  console.log(this.state.nameofcx,"name of agent ")
    }
    
    );
    
  flex.MessageInput.Content.add(<CannedResponses key="canned-responses" agentname={this.state.nameofcx}/>);
    console.log(this.state.nameofcx,"name of agent ")
   
    // flex.MessageInput.Content.replace("textarea", {options});
  

    // flex.Component.Content.remove(MessageInput, {options});
    manager.chatClient.on('channelJoined', (payload) => {
      // define a message to send into the channel - alternatively you could look it up here

      // let body = `Hi! I'm ${manager.workerClient.attributes.full_name} and this is our predefined message.`;
      let body   =`Hi, ${manager.workerClient.attributes.full_name}! We’re here to help you with your (insert ticket concern). Before we proceed, we’d just like to share with you our Data Privacy policy:
      IMPORTANT: NOTICE FOR CUSTOMERS By replying to this message and providing personal information that will allow us to assist you with your concern, you hereby consent to the processing, monitoring, and recording of personal information provided for use of Philippine Airlines products, services, and promotions, its disclosure or transfer by Philippine Airlines to its affiliates, third-party providers, consistent with applicable laws, rules, and regulations. The processing of your personal information is covered by DATA PRIVACY POLICY of Philippine Airlines and that by replying to this message, you hereby acknowledge that you have read and understood the DATA PRIVACY POLICY of Philippine Airlines.
     For the full Data Privacy disclosure, please visit https://bit.ly/PAL-Data-Privacy.`;
   
     
     flex.Actions.invokeAction('SendMessage', {
        
        channelSid: payload.sid,
        body: body
      });
    });
  }
}
