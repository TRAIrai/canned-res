import * as FlexPlugin from 'flex-plugin';
import AgentAutoresponsePlugin from './AgentAutoresponsePlugin';

FlexPlugin.loadPlugin(AgentAutoresponsePlugin);
